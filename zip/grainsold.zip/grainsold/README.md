# Grains
Simulation of physical systems based on granular particles
