#!/bin/bash
x=102
echo "x = $x"
