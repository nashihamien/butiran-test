<?php
	$x = 102;
	echo "x = $x";
?>
