var x = 102;
document.write("x = " + x);
