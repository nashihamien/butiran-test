#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
	int x = 102;
	cout << "x = " << x << endl;
	return 0;
}